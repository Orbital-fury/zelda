package zelda.objects;

public class Shield {
    
    public enum Kind {
        SMALL,
        MAGICAL
    }
}
