package zelda.scenary;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import zelda.Orientation;
import zelda.Zelda;
import zelda.enemies.Enemy;

import com.golden.gamedev.object.PlayField;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.collision.AdvanceCollisionGroup;
import com.golden.gamedev.object.collision.BasicCollisionGroup;

import java.io.*;
import java.nio.file.*;

public class Quest extends PlayField {
    
    private Zelda game;
    
    private Board[][] boards;
    
    private QuestMenu menu;
    
    private SpriteGroup rubySG;
    private  SpriteGroup enemySG;
    private  SpriteGroup enemy4D; 
    private  SpriteGroup linkSG;
    private SpriteGroup[][] boardSG;
    
    private Board currentBoard;
    private int currentBoardX;
    private int currentBoardY;
    
    public Quest(Zelda game) {
        super();
        this.game = game;
        this.boards = new Board[4][2];
        this.initRessources();
        currentBoardX = 2;
        currentBoardY = 0;
        currentBoard = this.boards[currentBoardX][currentBoardY];
        this.boardSG = new SpriteGroup[4][2];
        this.rubySG = new SpriteGroup("RUBY SPRITE GROUPE");
        this.enemySG = new SpriteGroup("ENEMYGD SPRITE GROUPE");
        this.enemy4D = new SpriteGroup("ENEMY4D SPRITE GROUPE");
        this.linkSG = new SpriteGroup("LINK SPRITE GROUPE");
        this.addGroup(enemy4D);
        this.addGroup(enemySG);
        this.addGroup(rubySG);
        this.addGroup(linkSG);
        this.addCollisionGroup(rubySG, linkSG, new RubyCollisionManager());
    }
    
	private void createBoard() {
	    	
		Path dir = Paths.get("C:\\Users\\Simon\\Documents\\zelda\\res\\boards");
	
		try {
			DirectoryStream<Path> stream = Files.newDirectoryStream(dir);
			{
				int i = 0;
				int j = 0;
				for (Path file : stream) {
	
					i = Integer.parseInt(file.getFileName().toString().substring(2,3)) ;
	
					j = Integer.parseInt(file.getFileName().toString().substring(4,5)) ;
	
					boards [i][j] = new Board(this.game, i, j);
	
					if (Files.isRegularFile(file)) {
	
						try (BufferedReader reader = new BufferedReader(new FileReader(file.toFile()))) {
	
							String line;
	
							while ((line = reader.readLine()) != null) {
	
								String[] terms = line.split(",");
	
								for (int m = 0; m < terms.length ; m++) {
	
									if (terms [m].matches("^[FR][0-9]{1,3}$")) {
	
										char a = terms[m].charAt(0);
	
										int b = Integer.parseInt(terms[m].substring(1)) ;
										switch (a) {
										case 'F':
											boards[i][j].add(new Floor(this.game, Zelda.mapFloor.get(b)));
	
											break;
										case 'R':
											System.out.println(b);
											boards[i][j].add(new Rock(this.game, Zelda.mapRock.get(b)));
											break;
										}
									}
								}
							}	
							
							reader.close();
						}
					}
					
				}
				this.add(boards[i][j]) ;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
    }

    private void initRessources() {
        this.menu = new QuestMenu(this.game);
        
        createBoard();       
        
    }
    
    public QuestMenu getMenu() {
    	return menu;
    }
    
    public void setEnvironnement() {
    	Board b = boards[2][0];
    	b.setEnemyOnBoard("01", 160, 450);
        b.setEnemyOnBoard("01", 160, 450);
        
        boardSG[0][0] = b.getForeground();
    	this.addGroup(boardSG[0][0]);
    	this.addCollisionGroup(enemySG, this.boardSG[0][0], new EnemyGDCollisionManager());
    	this.addCollisionGroup(enemy4D, this.boardSG[0][0], new Enemy4DCollisionManager());
    	//this.addCollisionGroup(linkSG, this.boardSG[0][0], new LinkCollisionManager());
    	//this.addCollisionGroup(linkSG, enemySG, new LinkCollisionManager());
    	//this.addCollisionGroup(linkSG, enemy4D, new LinkCollisionManager());
    	this.addCollisionGroup(enemySG, linkSG, new EnemyGDCollisionManager());
    	this.addCollisionGroup(enemy4D, linkSG, new Enemy4DCollisionManager());
        
        b.createRuby(200, 260);
        b.createRuby(450, 400);
    }
    
    
    public Board getCurrentBoard() {
        return this.boards[currentBoardX][currentBoardY];
    }
    
    public int getCurrentBoardX() {
        return this.currentBoardX;
    }
    
    public int getCurrentBoardY() {
        return this.currentBoardY;
    }
    
    public void setCurrentBoard(int x, int y) {
    	currentBoardX = x;
    	currentBoardY = y;
        currentBoard = this.boards[x][y];
    }
    
    public Board[][] getBoards() {
    	return boards;
    }
    
    public SpriteGroup getRubySG() {
    	return rubySG;
    }
    
    public SpriteGroup getLinkSG() {
    	return linkSG;
    }
    
    public SpriteGroup getEnemySG() {
    	return enemySG;
    }
    public SpriteGroup getEnemy4D() {
    	return enemy4D;
    }
    
    public void add(Board board) {
        //this.addGroup(board.getBackground());
        //this.addGroup(board.getForground());
        this.boards[board.getX()][board.getY()] = board;
    }
        
    public void update(long elapsedTime) {
        super.update(elapsedTime);
        //this.boards[0][0].update(elapsedTime);
        this.getCurrentBoard().update(elapsedTime);
        this.menu.update(elapsedTime);
        
        this.checkCollisions();
    }
    
    public void render(Graphics2D g) {
        super.render(g);
        //this.boards[0][0].render(g);
        this.getCurrentBoard().render(g);
        this.menu.render(g);
    }
    
    protected class RubyCollisionManager extends BasicCollisionGroup {
		
		public RubyCollisionManager() {
            this.pixelPerfectCollision = false;
        }
        // s1 ruby ; s2 link
        public void collided(Sprite s1, Sprite s2) {
        	if (s1.isActive()) {
        		menu.gainRuby(1);
        		System.out.println(menu.getNbrRuby());
        		s1.moveX(1000);
        	}
        	s1.setActive(false);
        }
    }
    
    private class EnemyGDCollisionManager extends AdvanceCollisionGroup {
        public EnemyGDCollisionManager() {
            this.pixelPerfectCollision = false;
        }
        
        public void collided(Sprite s1, Sprite s2) {
        	Enemy enemy = (Enemy) s1;
        
        	if (this.getCollisionSide() == Orientation.EAST.ordinal() ) {
        		
        		enemy.setOrientation(Orientation.WEST);
        		
        	} else if (this.getCollisionSide() == Orientation.WEST.ordinal() ) {
            		
        		enemy.setOrientation(Orientation.EAST);
            }
        }
    }
    
    private class Enemy4DCollisionManager extends AdvanceCollisionGroup {
    	
		public Enemy4DCollisionManager() {
			this.pixelPerfectCollision = false;
		}
		
		public void collided(Sprite s1, Sprite s2) {
		//	System.out.println(this.collisionSide);
			//Enemy enemy = (Enemy) s1;
			this.revertPosition1();	

		}

	}
}
